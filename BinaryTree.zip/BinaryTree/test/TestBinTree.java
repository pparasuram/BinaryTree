public class TestBinTree {
}
